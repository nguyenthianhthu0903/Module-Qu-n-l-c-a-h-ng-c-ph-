import java.io.*;
import java.util.*;

public class StoreManagement {
    private ArrayList<Staff> staffs;
    private ArrayList<String> workingTime;
    private ArrayList<Invoice> invoices;
    private ArrayList<InvoiceDetails> invoiceDetails;
    private ArrayList<Drink> drinks;

    public StoreManagement(String staffPath, String workingTimePath, String invoicesPath, String detailsPath,
            String drinksPath) {
        this.staffs = loadStaffs(staffPath);
        this.workingTime = loadFile(workingTimePath);
        this.invoices = loadInvoices(invoicesPath);
        this.invoiceDetails = loadInvoicesDetails(detailsPath);
        this.drinks = loadDrinks(drinksPath);
    }

    public ArrayList<Staff> getStaffs() {
        return this.staffs;
    }

    public void setStaffs(ArrayList<Staff> staffs) {
        this.staffs = staffs;
    }

    public ArrayList<Drink> loadDrinks(String filePath) {
        ArrayList<Drink> drinksResult = new ArrayList<Drink>();
        ArrayList<String> drinks = loadFile(filePath);

        for (String drink : drinks) {
            String[] temp = drink.split(",");
            drinksResult.add(new Drink(temp[0], Integer.parseInt(temp[1])));
        }

        return drinksResult;
    }

    public ArrayList<Invoice> loadInvoices(String filePath) {
        ArrayList<Invoice> invoiceResult = new ArrayList<Invoice>();
        ArrayList<String> invoices = loadFile(filePath);

        for (String invoice : invoices) {
            String[] temp = invoice.split(",");
            invoiceResult.add(new Invoice(temp[0], temp[1], temp[2]));
        }

        return invoiceResult;
    }

    public ArrayList<InvoiceDetails> loadInvoicesDetails(String filePath) {
        ArrayList<InvoiceDetails> invoiceResult = new ArrayList<InvoiceDetails>();
        ArrayList<String> invoices = loadFile(filePath);

        for (String invoice : invoices) {
            String[] temp = invoice.split(",");
            invoiceResult.add(new InvoiceDetails(temp[0], temp[1], Integer.parseInt(temp[2])));
        }

        return invoiceResult;
    }

    // requirement 1
    public ArrayList<Staff> loadStaffs(String filePath) {
        ArrayList<Staff> myList = new ArrayList<Staff>();
        File input = new File(filePath);
        String[] s = new String[100];
        try {
            try (Scanner scanner = new Scanner(input)) {
                do {
                    String l = scanner.nextLine();
                    s = l.split(",");
                    if (s[0].charAt(0) == 'T') {
                        String sID = s[0];
                        String sName = s[1];
                        int hourlyWage = Integer.parseInt(s[2]);
                        SeasonalStaff seasonalStaff = new SeasonalStaff(sID, sName, hourlyWage);
                        myList.add(seasonalStaff);

                    } else if (s[0].charAt(0) == 'C') {
                        String sID = s[0];
                        String sName = s[1];
                        int baseSalary = Integer.parseInt(s[2]);
                        double bonusRate = Double.parseDouble(s[3]);
                        FullTimeStaff fullTimeStaff = new FullTimeStaff(sID, sName, baseSalary, bonusRate);
                        myList.add(fullTimeStaff);
                    } else if (s[0].charAt(0) == 'Q') {
                        String sID = s[0];
                        String sName = s[1];
                        int baseSalary = Integer.parseInt(s[2]);
                        double bonusRate = Double.parseDouble(s[3]);
                        int allowance = Integer.parseInt(s[4]);
                        Manager manager = new Manager(sID, sName, baseSalary, bonusRate, allowance);
                        myList.add(manager);
                    }

                } while (scanner.hasNextLine());
            } catch (NumberFormatException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } catch (IOException e) {
            System.out.println("Fail");
            e.printStackTrace();
        }

        return myList;
    }

    // requirement 2
    public ArrayList<SeasonalStaff> getTopFiveSeasonalStaffsHighSalary() {
        // code here and modify the return value
        ArrayList<SeasonalStaff> myListResult = new ArrayList<SeasonalStaff>();
        ArrayList<SeasonalStaff> listSeasonalStaff = new ArrayList<SeasonalStaff>();

        ArrayList<Double> listSalary = new ArrayList<Double>();

        for (int i = 0; i < staffs.size(); i++) {
            if ((staffs.get(i) instanceof FullTimeStaff) == false)
                listSeasonalStaff.add((SeasonalStaff) staffs.get(i));
            else
                continue;
        }

        for (int j = 0; j < listSeasonalStaff.size(); j++) {
            if (listSeasonalStaff.get(j) instanceof SeasonalStaff) {
                for (int k = 0; k < workingTime.size(); k++) {
                    if (workingTime.get(k).contains(listSeasonalStaff.get(j).getsID())) {
                        String[] temp = workingTime.get(k).split(",");
                        listSalary.add(listSeasonalStaff.get(j).paySalary(Integer.parseInt(temp[1])));
                    }
                }
            }
        }

        for (int m = 0; m < listSeasonalStaff.size(); m++) {
            for (int n = m + 1; n < listSeasonalStaff.size(); n++) {
                if (listSalary.get(m) < listSalary.get(n)) {
                    SeasonalStaff temp = listSeasonalStaff.get(m);
                    listSeasonalStaff.set(m, listSeasonalStaff.get(n));
                    listSeasonalStaff.set(n, temp);
                    Double tempSalary = listSalary.get(m);
                    listSalary.set(m, listSalary.get(n));
                    listSalary.set(n, tempSalary);
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            myListResult.add(listSeasonalStaff.get(i));
        }
        return myListResult;

    }

    // requirement 3
    public ArrayList<FullTimeStaff> getFullTimeStaffsHaveSalaryGreaterThan(int lowerBound) {
        // code here and modify the return value
        ArrayList<FullTimeStaff> FullTimeStaffResult = new ArrayList<FullTimeStaff>();
        ArrayList<FullTimeStaff> listOfFullTimeStaff = new ArrayList<FullTimeStaff>();
        ArrayList<Double> listSalary = new ArrayList<Double>();

        for (int i = 0; i < staffs.size(); i++) {
            if ((staffs.get(i) instanceof SeasonalStaff) == false)
                listOfFullTimeStaff.add((FullTimeStaff) staffs.get(i));
            else
                continue;
        }

        for (int j = 0; j < listOfFullTimeStaff.size(); j++) {
            if (listOfFullTimeStaff.get(j) instanceof FullTimeStaff) {
                for (int i = 0; i < workingTime.size(); i++) {
                    if (workingTime.get(i).contains(listOfFullTimeStaff.get(j).getsID())) {
                        String[] information = workingTime.get(i).split(",");
                        listSalary.add(listOfFullTimeStaff.get(j).paySalary(Integer.parseInt(information[1])));
                    }
                }
            }
        }

        for (int i = 0; i < listOfFullTimeStaff.size(); i++) {
            if (listSalary.get(i) > lowerBound) {
                FullTimeStaffResult.add(listOfFullTimeStaff.get(i));
            }
        }
        return FullTimeStaffResult;
    }

    // requirement 4
    public double totalInQuarter(int quarter) {
        double total = 0;
        // code here
        ArrayList<Invoice> listInvoiceInQuarter = new ArrayList<Invoice>();
        ArrayList<InvoiceDetails> listInvoiceDetailInQuarter = new ArrayList<InvoiceDetails>();

        for (int i = 0; i < invoices.size(); i++) {
            String[] Month = invoices.get(i).getDate().split("/");
            int month = Integer.parseInt(Month[1]);
            String q1 = "1,2,3";
            String[] tempQ1 = q1.split(",");
            String q2 = "4,5,6";
            String[] tempQ2 = q2.split(",");
            String q3 = "7,8,9";
            String[] tempQ3 = q3.split(",");
            String q4 = "10,11,12";
            String[] tempQ4 = q4.split(",");

            if (quarter == 1) {
                for (int j = 0; j < tempQ1.length; j++) {
                    String k = (tempQ1[j]);
                    if (k.contains(Integer.toString(month))) {
                        listInvoiceInQuarter.add(invoices.get(i));
                    }
                }
            }
            if (quarter == 2) {
                for (int j = 0; j < tempQ2.length; j++) {
                    String k = (tempQ2[j]);
                    if (k.contains(Integer.toString(month))) {
                        listInvoiceInQuarter.add(invoices.get(i));
                    }
                }
            }
            if (quarter == 3) {
                for (int j = 0; j < tempQ3.length; j++) {
                    String k = (tempQ3[j]);
                    if (k.contains(Integer.toString(month))) {
                        listInvoiceInQuarter.add(invoices.get(i));
                    }
                }
            }
            if (quarter == 4) {
                for (int j = 0; j < tempQ4.length; j++) {
                    String k = (tempQ4[j]);
                    if (k.contains(Integer.toString(month))) {
                        listInvoiceInQuarter.add(invoices.get(i));
                    }
                }
            }

        }

        for (int i = 0; i < invoiceDetails.size(); i++) {
            for (int j = 0; j < listInvoiceInQuarter.size(); j++) {
                if (listInvoiceInQuarter.get(j).getInvoiceID().equals(invoiceDetails.get(i).getInvoiceID())) {
                    listInvoiceDetailInQuarter.add(invoiceDetails.get(i));
                }
            }
        }

        for (int m = 0; m < listInvoiceDetailInQuarter.size(); m++) {
            for (int n = 0; n < drinks.size(); n++) {
                if (drinks.get(n).getdName().equals(listInvoiceDetailInQuarter.get(m).getDName())) {
                    total += listInvoiceDetailInQuarter.get(m).getAmount() * drinks.get(n).getPrice();
                }
            }
        }
        return total;
    }

    // requirement 5
    public Staff getStaffHighestBillInMonth(int month) {
        Staff maxStaff = null;
        // code here
		ArrayList<Invoice> listInvoiceInMonth=new ArrayList<Invoice>();
		ArrayList<InvoiceDetails> listInvoiceDetailInMonth=new ArrayList<InvoiceDetails>();
		ArrayList<Double> listMoneyOfStaff=new ArrayList<Double>();
		ArrayList<String> listDistinctStaff=new ArrayList<String>();
		
		for (int i = 0; i < invoices.size(); i++) {
            String[] Month = invoices.get(i).getDate().split("/");
            int tempMonth = Integer.parseInt(Month[1]);
			if(tempMonth==month)
                        listInvoiceInMonth.add(invoices.get(i));
            }
		listDistinctStaff.add(listInvoiceInMonth.get(0).getStaffID());
		for (int i=1; i<listInvoiceInMonth.size(); i++)	{
			if (!(listDistinctStaff.contains(listInvoiceInMonth.get(i).getStaffID())))
				listDistinctStaff.add(listInvoiceInMonth.get(i).getStaffID());
			else continue;
		}
		
		for (InvoiceDetails invDet : invoiceDetails){
			for (Invoice inv:listInvoiceInMonth){
			if(invDet.getInvoiceID().equals(inv.getInvoiceID()))	listInvoiceDetailInMonth.add(invDet);
			}
		}
		
		for (int i=0; i<listDistinctStaff.size();i++){
			double tempMoneyOfStaff=0;
				for(int j=0; j<listInvoiceInMonth.size();j++)	{	
					if (listDistinctStaff.get(i).equals(listInvoiceInMonth.get(j).getStaffID())){
						for(InvoiceDetails invDet : listInvoiceDetailInMonth)	{
							if(invDet.getInvoiceID().equals(listInvoiceInMonth.get(j).getInvoiceID())){
									for (Drink dr:drinks)	{
										if (invDet.getDName().equals(dr.getdName()))
										tempMoneyOfStaff+=(invDet.getAmount()*dr.getPrice());
								}	
							}
						}	
					}	
				}
			listMoneyOfStaff.add(tempMoneyOfStaff);
		}
		
		for (int m = 0; m < listMoneyOfStaff.size(); m++) {
            for (int n = m + 1; n < listMoneyOfStaff.size(); n++) {
                if (listMoneyOfStaff.get(m) < listMoneyOfStaff.get(n)) {
                    String tempID = listDistinctStaff.get(m);
                    listDistinctStaff.set(m, listDistinctStaff.get(n));
                    listDistinctStaff.set(n, tempID);
                    Double tempMoney = listMoneyOfStaff.get(m);
                    listMoneyOfStaff.set(m, listMoneyOfStaff.get(n));
                    listMoneyOfStaff.set(n, tempMoney);
                }
            }
        }
		
		for (Staff s:staffs){
			if(s.getsID().equals(listDistinctStaff.get(0))) maxStaff=s;
		}
        return maxStaff;
    }

    // load file as list
    public static ArrayList<String> loadFile(String filePath) {
        String data = "";
        ArrayList<String> list = new ArrayList<String>();

        try {
            FileReader reader = new FileReader(filePath);
            BufferedReader fReader = new BufferedReader(reader);

            while ((data = fReader.readLine()) != null) {
                list.add(data);
            }

            fReader.close();
            reader.close();

        } catch (Exception e) {
            System.out.println("Cannot load file");
        }
        return list;
    }

    public void displayStaffs() {
        for (Staff staff : this.staffs) {
            System.out.println(staff);
        }
    }

    public <E> boolean writeFile(String path, ArrayList<E> list) {
        try {
            FileWriter writer = new FileWriter(path);
            for (E tmp : list) {
                writer.write(tmp.toString());
                writer.write("\r\n");
            }

            writer.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("Error.");
            return false;
        }

        return true;
    }

    public <E> boolean writeFile(String path, E object) {
        try {
            FileWriter writer = new FileWriter(path);

            writer.write(object.toString());
            writer.close();

            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("Error.");
            return false;
        }

        return true;
    }
}