public class Manager extends FullTimeStaff {
    private int allowance;

    public Manager(String sID, String sName, int baseSalary, double bonusRate, int allowance) {
        super(sID, sName, baseSalary, bonusRate);
        this.allowance = allowance;
    }

    public double getAllowance() {
        return this.allowance;
    }

    public void setAllowance(int allowance) {
        this.allowance = allowance;
    }

    @Override
    public double paySalary(int workedDays) {
        return super.paySalary(workedDays) + this.allowance;
    }

    @Override
    public String toString() {
        return super.toString() + "_" + this.allowance;
    }
}